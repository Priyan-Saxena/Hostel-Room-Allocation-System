# Hostel Room Allocation System

## Project Overview
A console-based C programming application designed to automate hostel room allocation management. The system helps administrators efficiently manage student registrations, room assignments, and occupancy tracking for up to 50 rooms.

## Key Features
- **Student Registration**: Add students with name, roll number, contact, and branch details
- **Room Allocation**: Assign available rooms to students with automatic vacancy checking
- **Search Functionality**: Find students by name, roll number, or room number
- **Occupancy Reports**: View detailed room status and vacancy percentages
- **Checkout System**: Deallocate rooms when students leave
- **Data Persistence**: Automatically save and load data from files across sessions
- **Input Validation**: Prevent duplicate roll numbers and invalid entries
- **Menu-Driven Interface**: Easy-to-use console navigation

## Project Architecture
### Technology Stack
- Language: C (C99 standard)
- Compiler: GCC
- Build System: Makefile
- Data Storage: File-based (hostel_data.txt)

### File Structure
```
hostel_system.c - Main application source code
Makefile - Build configuration
hostel_data.txt - Persistent data storage (auto-generated)
replit.md - Project documentation
```

### Data Structures
- **Student**: Stores name, roll number, contact, branch, room assignment, allocation status, and active status
- **Room**: Tracks room number, occupancy status, and occupant details

### Key Implementation Features
- **Slot Reuse System**: Students are marked as active/inactive instead of being deleted, allowing unlimited student turnover
- **Dynamic Memory Management**: System can handle unlimited add/checkout cycles without hitting capacity limits
- **State Persistence**: Complete system state (including active/inactive status) is preserved across save/load operations

## How to Use
The system runs through a menu-driven interface:

1. **Add New Student** - Register student details
2. **Allocate Room** - Assign available room to registered student
3. **Search Student** - Find by name/roll number/room number
4. **Display Occupancy Report** - View room status and statistics
5. **Checkout Student** - Free up room when student leaves
6. **Display All Students** - List all registered students
7. **Save Data** - Manually save to file
8. **Load Data** - Manually load from file
9. **Exit** - Auto-saves and closes application

## Recent Changes
- **2025-11-21**: Complete project implementation with production-ready bug fixes
  - Implemented all 8 core features (registration, allocation, search, reports, checkout, display, save/load)
  - Added comprehensive input validation (duplicate prevention, format checking)
  - Configured automatic data persistence with state restoration
  - Set up build system with Makefile and workflow configuration
  - **Bug Fix**: Implemented slot reuse mechanism with isActive tracking to allow unlimited student turnover
  - **Bug Fix**: Added proper state initialization in loadDataFromFile to prevent stale data issues
  - Verified complete system functionality through architectural review

## Technical Details
- Maximum capacity: 50 rooms (with unlimited student turnover via slot reuse)
- One student per room constraint
- Automatic save on exit
- Case-insensitive name search
- Phone number validation (minimum 10 digits)
- Duplicate roll number prevention
- Active/inactive student tracking for efficient memory management
- Complete state persistence including allocation and active status

## Building and Running
To compile the program:
```bash
make
```

To run the program:
```bash
./hostel_system
```

To clean build artifacts:
```bash
make clean
```
